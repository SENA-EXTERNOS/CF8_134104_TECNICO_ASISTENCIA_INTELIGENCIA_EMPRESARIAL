function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Q6gbxCZH94":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

